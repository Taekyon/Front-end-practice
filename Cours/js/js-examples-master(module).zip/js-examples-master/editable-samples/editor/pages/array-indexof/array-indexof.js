var cmInitContent = 
`// create an array
var beasts = ['ant', 'bison', 'camel', 'duck', 'bison'];

// call indexOf(), passing a value and optional start index
var index = beasts.indexOf('bison');

// log the result
console.log(index);`;

var cmSelectLine = 4;
var cmSelectChStart = 27;

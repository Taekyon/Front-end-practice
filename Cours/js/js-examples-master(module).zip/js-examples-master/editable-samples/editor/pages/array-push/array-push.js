var cmInitContent = 
`// create an array
var exampleArray = ['pigs', 'goats', 'sheep']

// add one or more elements
exampleArray.push('cows');

// log the result
console.log(exampleArray);`;

var cmSelectLine = 4;
var cmSelectChStart = 18;
